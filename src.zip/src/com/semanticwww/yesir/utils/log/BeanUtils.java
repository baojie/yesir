/**
 * $RCSfile: BeanUtils.java,v $
 * $Revision: 1.3 $
 * $Date: 2002/06/10 14:44:58 $
 *
 * Copyright (C) 1999-2001 CoolServlets, Inc. All rights reserved.
 *
 * This software is the proprietary information of CoolServlets, Inc.
 * Use is subject to license terms.
 */

package com.semanticwww.yesir.utils.log ;

import java.beans.BeanInfo ;
import java.beans.IntrospectionException ;
import java.beans.Introspector ;
import java.beans.PropertyDescriptor ;
import java.util.HashMap ;
import java.util.Iterator ;
import java.util.Map ;
import java.util.StringTokenizer ;

import java.awt.Color ;

import com.semanticwww.yesir.utils.string.StringUtils ;

/**
 * A utility class that provides methods that are useful for dealing with
 * Java Beans.
 */
public class BeanUtils
{

    /**
     * Sets the properties of a Java Bean based on the String name/value pairs in
     * the specifieed Map. Because this method has to know how to convert a
     * String value into the correct type for the bean, only a few bean property
     * types are supported. They are: String, boolean, int, long, float, double,
     * Color, and Class.<p>
     *
     * If key/value pairs exist in the Map that don't correspond to properties
     * of the bean, they will be ignored.
     *
     * @param bean the JavaBean to set properties on.
     * @param properties String name/value pairs of the properties to set.
     */
    public static void setProperties( Object bean , Map properties )
    {
        try
        {
            // Loop through all the property names in the Map
            for( Iterator iter = properties.keySet().iterator() ; iter.hasNext() ; )
            {
                String propName = ( String ) iter.next() ;
                try
                {
                    // Create a property descriptor for the named property. If
                    // the bean doesn't have the named property, an
                    // Introspection will be thrown.
                    PropertyDescriptor descriptor = new PropertyDescriptor(
                        propName , bean.getClass() ) ;
                    // Load the class type of the property.
                    Class propertyType = descriptor.getPropertyType() ;
                    // Get the value of the property by converting it from a
                    // String to the correct object type.
                    Object value = decode( propertyType ,
                                           ( String ) properties.get( propName ) ) ;
                    // Set the value of the bean.
                    descriptor.getWriteMethod().invoke( bean , new Object[]
                        {value} ) ;
                }
                catch( IntrospectionException ie )
                {
                    // Ignore. This exception means that the key in the map
                    // does not correspond to a property of the bean.
                }
            }
        }
        catch( Exception e )
        {
            e.printStackTrace() ;
        }
    }

    /**
     * Gets the properties from a Java Bean and returns them in a Map of String
     * name/value pairs. Because this method has to know how to convert a
     * bean property into a String value, only a few bean property
     * types are supported. They are: String, boolean, int, long, float, double,
     * Color, and Class.
     *
     * @param bean a Java Bean to get properties from.
     * @return a Map of all properties as String name/value pairs.
     */
    public static Map getProperties( Object bean )
    {
        Map properties = new HashMap() ;
        try
        {
            BeanInfo beanInfo = Introspector.getBeanInfo( bean.getClass() ) ;
            // Loop through all properties of the bean.
            PropertyDescriptor[] descriptors = beanInfo.getPropertyDescriptors() ;
            String[] names = new String[descriptors.length] ;
            for( int i = 0 ; i < names.length ; i++ )
            {
                // Determine the property name.
                String name = descriptors[i].getName() ;
                // Decode the property value using the property type and
                // encoded String value.
                Object value = descriptors[i].getReadMethod().invoke( bean , null ) ;
                // Add to Map, encoding the value as a String.
                properties.put( name , encode( value ) ) ;
            }
        }
        catch( Exception e )
        {
            e.printStackTrace() ;
        }
        return properties ;
    }

    /**
     * Returns the PropertyDescriptor array for the specified Java Bean Class.
     * The method also does a special check to see of the bean has a BeanInfo
     * class that extends the JiveBeanInfo class. If yes, we load the
     * PropertyDescriptor array directly from that BeanInfo class rather than
     * through the Introspector in order to preserve the desired ordering of
     * properties.
     *
     * @param beanClass the Class of the JavaBean.
     * @return the PropertyDescriptor array for the specified Java Bean Class.
     */
    public static PropertyDescriptor[] getPropertyDescriptors( Class beanClass )
        throws IntrospectionException
    {
        // See if the Java Bean has a BeanInfo class that implements
        // JiveBeanInfo. If so, return the PropertyDescriptor from that
        // class. This will bypass properties of parent classes, but this is
        // the normal behavior of classes that implement JiveBeanInfo.
        try
        {
            BeanInfoEx beanInfo = ( BeanInfoEx ) Class.forName(
                beanClass.getName() + "BeanInfo" ).newInstance() ;
            return beanInfo.getPropertyDescriptors() ;
        }
        catch( Exception e )
        {}
        // Otherwise, return the PropertyDescriptors from the Introspector.
        return Introspector.getBeanInfo( beanClass ).getPropertyDescriptors() ;
    }

    /**
     * Encodes a bean property value as a String. If the object type is not
     * supported, null will be returned.
     *
     * @param value an Object to encode in a String representation.
     */
    private static String encode( Object value )
    {
        if( value instanceof String )
        {
            return( String ) value ;
        }
        // String arrays are specially encoded: each value is base-64 encoded,
        // then delimited by a comma.
        if( value instanceof String[] )
        {
            StringBuffer result = new StringBuffer() ;
            String[] array = ( String[] ) value ;
            // Deal with fence post.
            if( array.length > 0 )
            {
                result.append( StringUtils.encodeBase64( array[0] ) ) ;
                for( int i = 1 ; i < array.length ; i++ )
                {
                    result.append( "," ).append( StringUtils.encodeBase64(
                        array[i] ) ) ;
                }
            }
            return result.toString() ;
        }
        if( value instanceof Boolean ||
            value instanceof Integer ||
            value instanceof Long ||
            value instanceof Float ||
            value instanceof Double )
        {
            return value.toString() ;
        }
        if( value instanceof Color )
        {
            Color color = ( Color ) value ;
            return color.getRed() + "," + color.getGreen() + "," +
                color.getBlue() ;
        }
        if( value instanceof Class )
        {
            return( ( Class ) value ).getName() ;
        }
        return null ;
    }

    /**
     * Decodes a String into an object of the specified type. If the object
     * type is not supported, null will be returned.
     *
     * @param type the type of the property.
     * @param value encode String value to decode.
     * @return the String value decoded into the specified type.
     */
    private static Object decode( Class type , String value )
        throws Exception
    {
        if( value == null )
        {
            return null ;
        }
        if( type.getName().equals( "java.lang.String" ) )
        {
            return value ;
        }
        // Check for String []
        if( type.getName().equals( "[Ljava.lang.String;" ) )
        {
            StringTokenizer tokens = new StringTokenizer( value , "," ) ;
            String[] result = new String[tokens.countTokens()] ;
            for( int i = 0 ; i < result.length ; i++ )
            {
                result[i] = StringUtils.decodeBase64( tokens.nextToken() ) ;
            }
            return result ;
        }
        if( type.getName().equals( "boolean" ) )
        {
            return Boolean.valueOf( value ) ;
        }
        if( type.getName().equals( "int" ) )
        {
            return Integer.valueOf( value ) ;
        }
        if( type.getName().equals( "long" ) )
        {
            return Long.valueOf( value ) ;
        }
        if( type.getName().equals( "float" ) )
        {
            return Float.valueOf( value ) ;
        }
        if( type.getName().equals( "double" ) )
        {
            return Double.valueOf( value ) ;
        }
        if( type.getName().equals( "java.awt.Color" ) )
        {
            StringTokenizer tokens = new StringTokenizer( value , "," ) ;
            int red = Integer.parseInt( tokens.nextToken() ) ;
            int green = Integer.parseInt( tokens.nextToken() ) ;
            int blue = Integer.parseInt( tokens.nextToken() ) ;
            return new Color( red , green , blue ) ;
        }
        if( type.getName().equals( "java.lang.Class" ) )
        {
            return Class.forName( value ) ;
        }
        return null ;
    }

    // This class is not instantiable.
    private BeanUtils()
    {
        // do nothing.
    }
}
